<?php
/**
 * Created by PhpStorm.
 * User: bvy
 * Date: 26.03.16
 * Time: 20:44
 */

class Bvy_News_Block_News extends Mage_Core_Block_Template{

    public function __construct(){
    $f=55;
}

    public function getNewsCollection()
    {
        $collection = Mage::getModel('bvy_news/news')->getCollection();
    }
}
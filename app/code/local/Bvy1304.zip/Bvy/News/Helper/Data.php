<?php
/**
 * Created by PhpStorm.
 * User: bvy
 * Date: 28.03.16
 * Time: 10:05
 */
class Bvy_News_Helper_Data extends  Mage_Core_Helper_Abstract
{
}

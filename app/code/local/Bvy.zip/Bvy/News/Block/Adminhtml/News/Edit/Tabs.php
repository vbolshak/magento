<?php
//создаем табу внутри уже определенного блока с тегом формы
class Bvy_news_Block_Adminhtml_News_Edit_Tabs extends Mage_Adminhtml_Block_Widget_Tabs
{

    public function __construct()
    {
        parent::__construct();
        $this->setId('form_tabs');
        $this->setDestElementId('edit_form'); // указываем имя формы которое определили в файле Form.php
        $this->setTitle(Mage::helper('news')->__('News Information'));
    }

    protected function _beforeToHtml()
    {   //добавляем табу
        $this->addTab('form_section_information', array(
            'label'     => Mage::helper('news')->__('Information'),
            'title'     => Mage::helper('news')->__('Information'),
            //добавляем в табу форму
            'content'   => $this->getLayout()->createBlock('news/adminhtml_news_edit_tab_forminformation')->toHtml(),
        ));
        $this->addTab('form_section_products', array(
            'label'     => Mage::helper('news')->__(' Attached products,'),
            'title'     => Mage::helper('news')->__(' Attached products,'),
            //добавляем в табу форму
            'content'   => $this->getLayout()->createBlock('news/adminhtml_news_edit_tab_form')->toHtml(),
        ));
        $this->addTab('form_section_design', array(
            'label'     => Mage::helper('news')->__('Custom Design'),
            'title'     => Mage::helper('news')->__(' Custom Design,'),
            //добавляем в табу форму
            'content'   => $this->getLayout()->createBlock('news/adminhtml_news_edit_tab_form')->toHtml(),
        ));


        return parent::_beforeToHtml();
    }
}
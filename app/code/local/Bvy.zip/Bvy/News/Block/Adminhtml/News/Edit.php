<?php
//создаем контейнер в котором будет наша форма
class Bvy_News_Block_Adminhtml_News_Edit extends Mage_Adminhtml_Block_Widget_Form_Container
{
    public function __construct()
    {
        parent::__construct();

        $this->_objectId = 'id';
        $this->_blockGroup = 'news'; //указываем групповое имя блока как в конфиге
        $this->_controller = 'adminhtml_news';

        $this->_updateButton('save', 'label', Mage::helper('news')->__('Save'));
        $this->_updateButton('delete', 'label', Mage::helper('news')->__('Delete'));

        $this->_addButton('saveandcontinue', array(
            'label'     => Mage::helper('adminhtml')->__('Save And Continue Edit'),
            'onclick'   => 'saveAndContinueEdit()',
            'class'     => 'save',
        ), -100);
    }

    public function getHeaderText()
    {
        return Mage::helper('news')->__('My Form Container');
    }
}
<?php
/**
 * Created by PhpStorm.
 * User: bvy
 * Date: 18.03.16
 * Time: 13:22
 */



class Bvy_News_ViewController extends Mage_Core_Controller_Front_Action {


    public function viewAction()
    {

       $s=5;

        $this->loadLayout();
        //  $this->getLayout()->createBlock('news/news');
        $this->renderLayout();

    }
}